package com.Mentor_Connect_Login_Service.LoginService.registerService;

import javax.persistence.Id;

import org.springframework.data.repository.CrudRepository;

import com.Mentor_Connect_Login_Service.LoginService.model.User;

public interface RegisterService extends CrudRepository<User, Id> {

}
