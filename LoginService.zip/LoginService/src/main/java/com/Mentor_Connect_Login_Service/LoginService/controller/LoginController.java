package com.Mentor_Connect_Login_Service.LoginService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.Mentor_Connect_Login_Service.LoginService.model.User;
import com.Mentor_Connect_Login_Service.LoginService.registerService.RegisterService;




@Controller
public class LoginController {
	@Autowired
	RegisterService registerService;
	
	
	@PostMapping("/Welcome")
	User create( User user) {
		System.out.println("Done");
		return registerService.save(user);
		
	}
	
	@RequestMapping( method = RequestMethod.POST)
	public String Register() {
		return "succeslogin";
	}
	@RequestMapping("/")
	public String welocme() {
		System.out.println("HELLO");
		return "Welcome.jsp";
	}
	@RequestMapping(value = "/succsregistration" , method = RequestMethod.GET)
	public String succesRegistration() {
		System.out.println("registered");
		return "succsregistration.jsp";
	}
}
